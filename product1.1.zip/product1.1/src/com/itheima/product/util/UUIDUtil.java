package com.itheima.product.util;

import java.util.UUID;

public class UUIDUtil {
	public static String getUUID(){
		return UUID.randomUUID().toString();//�õ������һ���ַ���
	}
	
/*	public static void main(String[] args) {
		System.out.println(getUUID());
	}*/
}
