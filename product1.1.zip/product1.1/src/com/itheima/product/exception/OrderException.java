package com.itheima.product.exception;

public class OrderException extends Exception {

	public OrderException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public OrderException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
