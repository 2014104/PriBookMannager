package student;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import util.DBHelper;

public class StudentDao {
	public ArrayList<Student> getAllStudent() throws Exception{
		ArrayList<Student> list=new ArrayList<Student>();
		Connection conn=DBHelper.getConnection();
		Statement stat=conn.createStatement();
		String sql="select * from stu6";
		ResultSet rs=stat.executeQuery(sql);
		while(rs.next()){
			Student stu=new Student();
			stu.setId(rs.getInt("id"));
			stu.setName(rs.getString("name"));
			stu.setSex(rs.getString("sex"));
			list.add(stu);
			
		}
		stat.close();
		conn.close();
		return list;		
	}

}
