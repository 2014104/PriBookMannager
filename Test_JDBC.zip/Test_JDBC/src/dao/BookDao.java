package dao;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;

import test_db.DBOper;

public class BookDao extends DBOper {
	public HashMap getAllBook() throws Exception{
		HashMap hm=new HashMap();
		String sql="select * from book";
		ResultSet rs=this.executeQuery(sql);
		while(rs.next()){
			Book stu=new Book();
			stu.setBookno(rs.getString("bookno"));
			stu.setBookname(rs.getString("bookname"));
			stu.setBookprice(rs.getFloat("bookprice"));
			hm.put(stu.getBookno(),stu);
			
		}
		return hm;		
	}

}
