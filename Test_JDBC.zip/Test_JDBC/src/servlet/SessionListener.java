package servlet;

import java.util.HashMap;

import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

public class SessionListener implements HttpSessionListener {

	
	public void sessionCreated(HttpSessionEvent arg0) {
		HttpSession session=arg0.getSession();
		HashMap books=new HashMap();
		session.setAttribute("books",books);//books���ﳵ��������
		session.setAttribute("money",0F);//����money����Ϊ0
		
	}

	@Override
	public void sessionDestroyed(HttpSessionEvent arg0) {
		
	}

}
