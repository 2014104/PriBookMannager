package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.Book;
import dao.BookDao;

public class RemoveServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		String bookno=request.getParameter("bookno");
		HttpSession session=request.getSession();
		HashMap books=(HashMap)session.getAttribute("books");
		Book book=(Book)books.get(bookno);
		float money=(Float)session.getAttribute("money");
		money=money-book.getBooknumber()*book.getBookprice();
		session.setAttribute("money",money);
		books.remove(bookno);//ɾ��ͼ�飬���ݼ�ɾ��
		response.sendRedirect("/Test_JDBC/showCart.jsp");
	}

}
