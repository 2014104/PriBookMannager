package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import vote.Votedba;



public class VoteServleta extends HttpServlet {

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		String[] teacherNo=request.getParameterValues("teacherNo");
        Votedba votedba=new Votedba();
        try {
        	Connection conn=votedba.getConn("localhost","student", "root", "1111");
			votedba.updateVote(teacherNo);
			votedba.closeAll();
		} catch (Exception e) {
			e.printStackTrace();
		}
        response.sendRedirect("/Test_JDBC/servlet/TeacherVotea");
        
	}

}
