package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import vote.Teacher;
import vote.Votedba;


public class TeacherVotea extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Votedba stud = new Votedba();
		ArrayList<Teacher> list=null;
		try {
			Connection conn=stud.getConn("localhost","student", "root", "1111");
			list = stud.getAllTeacher();
			stud.closeAll();
		} catch (Exception e) {
			e.printStackTrace();
		}
		request.getSession().setAttribute("teacher",list);
		response.sendRedirect("/Test_JDBC/display_M.jsp");
		
	}

}
