package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBHelper {
	private static final String driver = "com.mysql.jdbc.Driver"; // ���ݿ�����
	private static final String url = "jdbc:mysql://localhost:3306/student?useUnicode=true&characterEncoding=UTF-8";
	private static final String username = "root";
	private static final String password = "1111";

	public static Connection getConnection() throws Exception {
		Class.forName(driver);
		Connection conn = DriverManager.getConnection(url, username, password);
		return conn;
	}

}
