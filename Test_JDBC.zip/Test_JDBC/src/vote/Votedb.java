package vote;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import test_db.DBOper;
import util.DBHelper;

public class Votedb extends DBOper{
	public ArrayList<Teacher> getAllTeacher() throws Exception{
		ArrayList<Teacher> list=new ArrayList<Teacher>();	
		String sql="select * from votedb";
		ResultSet rs=this.executeQuery(sql);
		while(rs.next()){
			Teacher stu=new Teacher();
			stu.setTeacherNo(rs.getString("teacherNo"));
			stu.setTeacherName(rs.getString("teacherName"));
			stu.setVote(rs.getInt("vote"));
			list.add(stu);
			
		}
		return list;		
	}
	public void updateVote(String teacherNo) throws Exception{
		String sql="update votedb set vote=vote+1  where teacherNo=?";
        this.executeUpdate(sql,new String[]{teacherNo});
	}

}
