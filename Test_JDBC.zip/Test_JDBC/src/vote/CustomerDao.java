package vote;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import student.Student;
import util.DBHelper;

public class CustomerDao {
	public ArrayList<Teacher> getAllTeacher() throws Exception{
		ArrayList<Teacher> list=new ArrayList<Teacher>();
		Connection conn=DBHelper.getConnection();
		Statement stat=conn.createStatement();
		String sql="select * from votedb";
		ResultSet rs=stat.executeQuery(sql);
		while(rs.next()){
			Teacher stu=new Teacher();
			stu.setTeacherNo(rs.getString("teacherNo"));
			stu.setTeacherName(rs.getString("teacherName"));
			stu.setVote(rs.getInt("vote"));
			list.add(stu);
			
		}
		stat.close();
		conn.close();
		return list;		
	}
	public Student getNameByAccount(String account) throws Exception{
		Connection conn=DBHelper.getConnection();
		int accounta=Integer.parseInt(account);
		String sql="select * from stu6 where id=?";
        PreparedStatement ps=conn.prepareStatement(sql);
        ps.setInt(1, accounta);
        ResultSet rs=ps.executeQuery();
        Student stu=null;
		if(rs.next()){
		    stu=new Student();
			stu.setId(rs.getInt("id"));
			stu.setName(rs.getString("name"));
			stu.setSex(rs.getString("sex"));
		}
        ps.close();
        conn.close();
    	return stu;	

	}

}
