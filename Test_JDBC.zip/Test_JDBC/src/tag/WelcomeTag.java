package tag;

import java.io.IOException;

import javax.servlet.jsp.JspContext;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.SimpleTagSupport;

public class WelcomeTag extends SimpleTagSupport {
	private int time;
	public void setTime(int time) {
		this.time = time;
	}

	public void doTag() throws JspException,IOException{
		JspContext context=this.getJspContext();
		JspWriter out=context.getOut();
		for(int i=0;i<time;i++){
			out.println("��ӭ��������ϵͳ<br>");
		}
	}

}
