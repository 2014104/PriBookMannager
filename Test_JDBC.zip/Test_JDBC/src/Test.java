import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;


public class Test {

	public static void main(String[] args) throws SQLException{
		Connection conn=null;
		try{
		Class.forName("com.mysql.jdbc.Driver");
	    conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/student","root","1111");
        Statement stat=conn.createStatement();
        conn.setAutoCommit(false);
        String sql3="update stu4 set age=11 where id in(1,2)";
        String sql5="update stu4 set age=33 where id in(3,6)";
        stat.executeUpdate(sql3);
        stat.executeUpdate(sql5);
        conn.commit();
		}catch(Exception ex){
			conn.rollback();
		}
		finally{
			conn.close();
		}

	}

}
