package test_db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class DBOper {
	Connection conn = null;
	PreparedStatement ps = null;
	ResultSet rs = null;

	public Connection getConn(String server,String dbname,String user,String pwd) throws Exception{
		String DRIVER="com.mysql.jdbc.Driver";
		String 	URL="jdbc:mysql://"+server+":3306/"+dbname+"?user="+user+"&password="+pwd+"&useUnicode=true&characterEncoding=utf-8" ;		
		Class.forName(DRIVER);
		conn=DriverManager.getConnection(URL);
		return conn;
		
	}

	public void closeAll() throws Exception {
		if (rs != null) {
			rs.close();
		}
		if (ps != null) {
			ps.close();
		}
		if (conn != null) {
			conn.close();
		}

	}

	public ResultSet executeQuery(String sql, String[] param) throws Exception {
		ps = conn.prepareStatement(sql);
		for (int i = 0; i < param.length; i++) {
			ps.setString(i + 1, param[i]);
		}
		rs = ps.executeQuery();
		return rs;

	}

	public ResultSet executeQuery(String sql) throws Exception {
		ps = conn.prepareStatement(sql);
	    rs = ps.executeQuery();
		return rs;

	}

	public int executeUpdate(String sql, String[] param) throws Exception {
		int num = 0;
		ps = conn.prepareStatement(sql);
		for (int i = 0; i < param.length; i++) {
			ps.setString(i + 1, param[i]);
		}
		num = ps.executeUpdate();
		return num;
	}
}
