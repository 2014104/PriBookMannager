package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import vo.Course;
public class CourseDao {
	private Connection conn = null;
	private static final String driver = "com.mysql.jdbc.Driver"; // ���ݿ�����
	private static final String url = "jdbc:mysql://localhost:3306/goodedu?useUnicode=true&characterEncoding=UTF-8";
	private static final String username = "root";
	private static final String password = "1111";

	public void initConnection() throws Exception {
		Class.forName(driver);
		conn = DriverManager.getConnection(url, username, password);
	}
	public ArrayList getAllCoursename() throws Exception{//������пγ�����
		ArrayList al = new ArrayList();
		this.initConnection();
		String sql = "select distinct(coursename) from t_course";
		Statement stat = conn.createStatement();
		ResultSet rs = stat.executeQuery(sql);
		while(rs.next()){
			al.add(rs.getString("coursename").trim());
		}
		this.closeConnection();
		return al;
	}

	public ArrayList getAllCourse() throws Exception{//������пγ�
		ArrayList al = new ArrayList();
		this.initConnection();
		String sql = "select * from t_course A left outer join t_teacher B on A.teano = B.teano";
		Statement stat = conn.createStatement();
		ResultSet rs = stat.executeQuery(sql);
		while(rs.next()){
			Course cou = new Course();
			cou.setCourseno(rs.getString("courseno").trim());
			cou.setCoursename(rs.getString("coursename").trim());
			cou.setCredit(rs.getFloat("credit"));
			cou.setTeano(rs.getString("teano").trim());
			cou.setTeaname(rs.getString("teaname").trim());
			al.add(cou);
		}
		this.closeConnection();
		return al;
	}
	
	public Course getCourseByCourseno(String courseno) throws Exception{//���ݿγ̺Ż�ȡ�γ���Ϣ
		this.initConnection();
		Course cou = null;
		String sql = "select * from t_course A left outer join t_teacher B on A.teano = B.teano where A.courseno='"+courseno+"'";
		Statement stat = conn.createStatement();
		ResultSet rs = stat.executeQuery(sql);
		if(rs.next()){
			cou = new Course();
			cou.setCourseno(courseno);
			cou.setCoursename(rs.getString("coursename").trim());
			cou.setCredit(rs.getFloat("credit"));
			cou.setTeano(rs.getString("teano").trim());
			cou.setTeaname(rs.getString("teaname").trim());
		}
		this.closeConnection();
		return cou;
	}
	public ArrayList getCourseByTeano(String teano) throws Exception{//�����Ӧְ���ŵĿ������
		ArrayList al = new ArrayList();
		this.initConnection();
		String sql = "select * from t_course A left outer join t_teacher B on A.teano = B.teano where B.teano='"+teano+"'";;
		Statement stat = conn.createStatement();
		ResultSet rs = stat.executeQuery(sql);
		while(rs.next()){
			Course cou = new Course();
			cou.setCourseno(rs.getString("courseno").trim());
			cou.setCoursename(rs.getString("coursename").trim());
			cou.setCredit(rs.getFloat("credit"));
			cou.setTeano(teano);
			cou.setTeaname(rs.getString("teaname").trim());
			al.add(cou);
		}
		this.closeConnection();
		return al;
	}
	public ArrayList getCourseByStuno(String stuno) throws Exception{//�����Ӧѧ��ѡ�޺õĿγ�
		ArrayList al = new ArrayList();
		this.initConnection();
		String sql = "select * from t_course A join t_score B on A.courseno=B.courseno join t_teacher C on A.teano=C.teano" 
			+" where B.stuno='"+stuno+"'";
		Statement stat = conn.createStatement();
		ResultSet rs = stat.executeQuery(sql);
		while(rs.next()){
			Course cou = new Course();
			cou.setCourseno(rs.getString("courseno").trim());
			cou.setCoursename(rs.getString("coursename").trim());
			cou.setCredit(rs.getFloat("credit"));
			cou.setTeano(rs.getString("teano").trim());
			cou.setTeaname(rs.getString("teaname").trim());
			al.add(cou);
		}
		this.closeConnection();
		return al;
	}
	public void closeConnection() throws Exception{
		conn.close();
	}
//	 public static void main(String[] args) throws Exception {
//		 CourseDao db = new CourseDao();
//		 ArrayList a1=db.getAllCoursename();
//		 for(int i=0;i<a1.size();i++){
//			 System.out.println(a1.get(i));
//		 }
//		 ArrayList a1=db.getAllCourse();
//		 for(int i=0;i<a1.size();i++){
//			 Course cou=(Course) a1.get(i);
//			 System.out.println(cou.getCourseno());
//		 }
//		 }
 
	
}
